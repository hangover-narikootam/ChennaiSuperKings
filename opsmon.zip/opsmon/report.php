<html style="width:100%;height:100%;padding:0;margin:0;position:relative;text-align:center;">
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii"></head><body style="background-color: white; position: relative; text-align: cent
er; padding: 0; margin: 0;display: inline-block;"><div style="position: relative; text-align: center;">
<table style="background-color:#ffcc99; position: relative; text-align: center;" width="1200px" cellspacing="0px" cellpadding="5px">
<tr><td colspan="7"><table style="background-color:#4d4d4d;" width="1200px" cellspacing="0px" cellpadding="5px">
<tr><td width="10"></td><td width="100" align="left"></td><td width="650" align="right">
<h1 style="font-family: Courier; color:orange;text-align: center; font-size: 20px">
BDC - Eagle View Monitor 05/22/2024 06:49:01 AM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_retail" style="text-decoration: none;">Splunk Retail Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_ws" style="text-decoration: none;">Splunk Mobile Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_sso_banks" style="text-decoration: none;">Splunk SSO Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ccb_error_monitoring" style="text-decoration: none;">Splunk CCB Monitoring</a></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://localhost:84/rptview/eaglebdc.php" style="text-decoration: none;">Dashboard</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/retail_activessn.php" style="text-decoration: none;">Retail Active Sessions</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/responstime.php" style="text-decoration: none;">Retail JVM response time</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/ws_active_session.php" style="text-decoration: none;">Mobile Active Sessions</a></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://localhost:84/rptview/ofxcalls.php" style="text-decoration: none;">mbofx Calls</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/idscalls.php" style="text-decoration: none;">IDS call hits</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/ctmadashboard.php" style="text-decoration: none;">Batch JOb Status</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/FAQ.php" style="text-decoration: none;">FAQ</a></td></tr>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Retail ADM & BATCH Prob Calls</td>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px">
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">22A1</td>
<td align="center" width="40">22A2</td>
<td align="center" width="40">22A3</td>
<td align="center" width="40">22A4</td>
<td align="center" width="40">22A5</td>
<td align="center" width="40">22A6</td>
<td align="center" width="40">23A1</td>
<td align="center" width="40">23A2</td>
<td align="center" width="40">23A3</td>
<td align="center" width="40">23A4</td>
<td align="center" width="40">23A5</td>
<td align="center" width="40">23A6</td>
<td align="center" width="40">24C1</td>
<td align="center" width="40">24C2</td>
<td align="center" width="40">24C3</td>
<td align="center" width="40">24C4</td>
<td align="center" width="40">24C5</td>
<td align="center" width="40">24C6</td>
<td align="center" width="40">25C1</td>
<td align="center" width="40">25C2</td>
<td align="center" width="40">25C3</td>
<td align="center" width="40">25C4</td>
<td align="center" width="40">25C5</td>
<td align="center" width="40">25C6</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">26D1</td>
<td td align="center" width="40">26D2</td>
<td align="center" width="40">26D3</td>
<td align="center" width="40">26D4</td>
<td align="center" width="40">26D5</td>
<td align="center" width="40">26D6</td>
<td align="center" width="40">27D1</td>
<td align="center" width="40">27D2</td>
<td align="center" width="40">27D3</td>
<td align="center" width="40">27D4</td>
<td align="center" width="40">27D5</td>
<td align="center" width="40">27D6</td>
<td align="center" width="40">28E1</td>
<td align="center" width="40">28E2</td>
<td align="center" width="40">28E3</td>
<td align="center" width="40">28E4</td>
<td align="center" width="40">28E5</td>
<td align="center" width="40">28E6</td>
<td align="center" width="40">29E1</td>
<td align="center" width="40">29E2</td>
<td align="center" width="40">29E3</td>
<td align="center" width="40">29E4</td>
<td align="center" width="40">29E5</td>
<td align="center" width="40">29E6</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
</tr>
<table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"> <tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="50">30F1</td>
<td align="center" width="90">30F2</td>
<td align="center" width="90">30F3</td>
<td align="center" width="90">30F4</td>
<td align="center" width="90">30F5</td>
<td align="center" width="90">30F6</td>
<td align="center" width="90">31F1</td>
<td align="center" width="90">31F2</td>
<td align="center" width="90">31F3</td>
<td align="center" width="90">31F4</td>
<td align="center" width="90">31F5</td>
<td align="center" width="90">31F6</td>
<td align="center" width="90">40C1ADM</td>
<td align="center" width="90">40D1ADM</td>
<td align="center" width="90">41C1ADM</td>
<td align="center" width="90">41D1ADM</td>
<td align="center" width="90">42BATCH</td>
<td align="center" width="90">43BATCH</td>
<td align="center" width="90">44BATCH</td>
<td align="center" width="90">45BATCH</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">WS(Mobile)</td>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px">
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">JVM</td>
<td align="center" width="40">Agg_01A1</td>
<td align="center" width="40">Agg_01A2</td>
<td align="center" width="40">Agg_02A1</td>
<td align="center" width="40">Agg_02A2</td>
<td align="center" width="40">IBS_01A1</td>
<td align="center" width="40">IBS_01A2</td>
<td align="center" width="40">IBS_02A1</td>
<td align="center" width="40">IBS_02A2</td>
<td align="center" width="40">03D1</td>
<td align="center" width="40">03D2</td>
<td align="center" width="40">03D3</td>
<td align="center" width="40">03D4</td>
<td align="center" width="40">03D5</td>
<td align="center" width="40">03D6</td>
<td align="center" width="40">03D7</td>
<td align="center" width="40">03D8</td>
<td align="center" width="40">04D1</td>
<td align="center" width="40">04D2</td>
<td align="center" width="40">04D3</td>
<td align="center" width="40">04D4</td>
<td align="center" width="40">04D5</td>
<td align="center" width="40">04D6</td>
<td align="center" width="40">04D7</td>
<td align="center" width="40">04D8</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td td align=center width=20>PROB</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td td align=center width=20>ACINQ</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td td align=center width=20>CENTFY</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">MBOFX</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="140">MBOFX</td>
<td align="center" width="100">s01_1</td>
<td align="center" width="100">s01_2</td>
<td align="center" width="100">s02_1</td>
<td align="center" width="100">s02_2</td>
<td align="center" width="100">s03_1</td>
<td align="center" width="100">s03_2</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>36_APP</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>CNIN_APP</td>
<td align=center width=100 bgcolor=green>522</td>
<td align=center width=100 bgcolor=green>0
518</td>
<td align=center width=100 bgcolor=green>544</td>
<td align=center width=100 bgcolor=green>0
520</td>
<td align=center width=100 bgcolor=green>489</td>
<td align=center width=100 bgcolor=green>0
526</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>CNOUT_APP</td>
<td align=center width=100 bgcolor=green>522</td>
<td align=center width=100 bgcolor=green>0
518</td>
<td align=center width=100 bgcolor=green>544</td>
<td align=center width=100 bgcolor=green>0
520</td>
<td align=center width=100 bgcolor=green>489</td>
<td align=center width=100 bgcolor=green>0
526</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>ESP_APP</td>
<td align=center width=100 bgcolor=green>15</td>
<td align=center width=100 bgcolor=green>0
1</td>
<td align=center width=100 bgcolor=green>5</td>
<td align=center width=100 bgcolor=green>0
5</td>
<td align=center width=100 bgcolor=green>6</td>
<td align=center width=100 bgcolor=green>0
23</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>SVLT_APP</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0
0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0
0</td>
<td align=center width=100 bgcolor=green>0</td>
<td align=center width=100 bgcolor=green>0
0</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Https Service calls</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 12px; background-color:#808080"><td align="center" width="45">HTTPS</td>
<td align="center" width="45">02A</td>
<td align="center" width="45">03A</td>
<td align="center" width="45">04A</td>
<td align="center" width="45">05A</td>
<td align="center" width="45">02C</td>
<td align="center" width="45">03C</td>
<td align="center" width="45">04C</td>
<td align="center" width="45">05C</td>
<td align="center" width="45">02D</td>
<td align="center" width="45">03D</td>
<td align="center" width="45">04D</td>
<td align="center" width="45">05D</td>
<td align="center" width="45">02E</td>
<td align="center" width="45">03E</td>
<td align="center" width="45">04E</td>
<td align="center" width="45">05E</td>
<td align="center" width="45">02F</td>
<td align="center" width="45">03F</td>
<td align="center" width="45">04F</td>
<td align="center" width="45">05F</td></tr>
<tr style="font-family: Courier; color: white; font-size: 10px; background-color:black">
<td td align=center width=45>PRE-EAM</td>
<td align=center width=40 bgcolor=green>6</td>
<td align=center width=40 bgcolor=green>14</td>
<td align=center width=40 bgcolor=green>11</td>
<td align=center width=40 bgcolor=green>8</td>
<td align=center width=40 bgcolor=green>4</td>
<td align=center width=40 bgcolor=green>5</td>
<td align=center width=40 bgcolor=green>5</td>
<td align=center width=40 bgcolor=green>9</td>
<td align=center width=40 bgcolor=green>5</td>
<td align=center width=40 bgcolor=green>5</td>
<td align=center width=40 bgcolor=green>3</td>
<td align=center width=40 bgcolor=green>4</td>
<td align=center width=40 bgcolor=green>2</td>
<td align=center width=40 bgcolor=green>9</td>
<td align=center width=40 bgcolor=green>12</td>
<td align=center width=40 bgcolor=green>4</td>
<td align=center width=40 bgcolor=green>5</td>
<td align=center width=40 bgcolor=green>6</td>
<td align=center width=40 bgcolor=green>3</td>
<td align=center width=40 bgcolor=green>7</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 10px; background-color:black">
<td td align=center width=45>POST-EAM</td>
<td align=center width=40 bgcolor=green>27</td>
<td align=center width=40 bgcolor=green>49</td>
<td align=center width=40 bgcolor=green>42</td>
<td align=center width=40 bgcolor=green>30</td>
<td align=center width=40 bgcolor=green>39</td>
<td align=center width=40 bgcolor=green>27</td>
<td align=center width=40 bgcolor=green>38</td>
<td align=center width=40 bgcolor=green>33</td>
<td align=center width=40 bgcolor=green>33</td>
<td align=center width=40 bgcolor=green>47</td>
<td align=center width=40 bgcolor=green>32</td>
<td align=center width=40 bgcolor=green>43</td>
<td align=center width=40 bgcolor=green>34</td>
<td align=center width=40 bgcolor=green>38</td>
<td align=center width=40 bgcolor=green>46</td>
<td align=center width=40 bgcolor=green>28</td>
<td align=center width=40 bgcolor=green>27</td>
<td align=center width=40 bgcolor=green>24</td>
<td align=center width=40 bgcolor=green>46</td>
<td align=center width=40 bgcolor=green>33</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">synthetic test login status</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="140">SYNTH LOGINS</td>
<td align="center" width="100">108</td>
<td align="center" width="100">10N</td>
<td align="center" width="100">10P</td>
<td align="center" width="100">10T</td>
<td align="center" width="100">12Y</td>
<td align="center" width="100">535</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>STATUS</td>
<td align=center width=100 bgcolor=red>Failed</td>
<td align=center width=100 bgcolor=red>Failed</td>
<td align=center width=100 bgcolor=red>Failed</td>
<td align=center width=100 bgcolor=#ff9900>Deconverted</td>
<td align=center width=100 bgcolor=red>Failed</td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Gigaspace primary Secondary service Status</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="120">SERVER</td>
<td align="center" width="60">PU1</td>
<td align="center" width="60">PU1_1</td>
<td align="center" width="60">PU2</td>
<td align="center" width="60">PU2_1</td>
<td align="center" width="60">PU3</td>
<td align="center" width="60">PU3_1</td>
<td align="center" width="60">PU4</td>
<td align="center" width="60">PU4_1</td>
<td align="center" width="60">PU5</td>
<td align="center" width="60">PU5_1</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap50 </td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap51 </td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap52 </td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap53 </td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
</tr>
</table>
