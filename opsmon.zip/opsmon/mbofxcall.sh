#!/bin/bash
report=/fras/cebscr/checkup/opsmon/report.php

echo -e '</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">MBOFX</td>'>>$report

echo -e '</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="140">MBOFX</td>
<td align="center" width="100">s01_1</td>
<td align="center" width="100">s01_2</td>
<td align="center" width="100">s02_1</td>
<td align="center" width="100">s02_2</td>
<td align="center" width="100">s03_1</td>
<td align="center" width="100">s03_2</td></tr>'>>$report


ofx01_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400003237| cut -d "," -f4`
ofx01_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006579| sort -u| cut -d "," -f4`
ofx02_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400003238| cut -d "," -f4`
ofx02_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006580| sort -u| cut -d "," -f4`
ofx03_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400003239| cut -d "," -f4`
ofx03_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006581| sort -u| cut -d "," -f4`

if [ $ofx01_1 = 0 ]; then ofx01_1clr=green; else ofx01_1clr=red; fi
if [ $ofx01_2 = 0 ]; then ofx01_2clr=green; else ofx01_2clr=red; fi
if [ $ofx02_1 = 0 ]; then ofx02_1clr=green; else ofx02_1clr=red; fi
if [ $ofx02_2 = 0 ]; then ofx02_2clr=green; else ofx02_2clr=red; fi
if [ $ofx03_1 = 0 ]; then ofx03_1clr=green; else ofx03_1clr=red; fi
if [ $ofx03_2 = 0 ]; then ofx03_2clr=green; else ofx03_2clr=red; fi

echo -e '<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">'>>$report
echo -e "<td align="center" width="100">36_APP</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx01_1clr>$ofx01_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx01_2clr>$ofx01_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx02_1clr>$ofx02_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx02_2clr>$ofx02_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx03_1clr>$ofx03_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=$ofx03_2clr>$ofx03_2</td>">>$report
echo -e "</tr>">>$report

ofx01_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006515| cut -d "," -f4`
ofx01_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006516| cut -d "," -f4`
ofx02_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006517| cut -d "," -f4`
ofx02_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006518| cut -d "," -f4`
ofx03_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006519| cut -d "," -f4`
ofx03_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006520| cut -d "," -f4`

echo -e '<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">'>>$report
echo -e "<td align="center" width="100">CNIN_APP</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_2</td>">>$report
echo -e "</tr>">>$report

ofx01_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006531| cut -d "," -f4`
ofx01_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006532| cut -d "," -f4`
ofx02_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006533| cut -d "," -f4`
ofx02_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006534| cut -d "," -f4`
ofx03_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006535| cut -d "," -f4`
ofx03_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006536| cut -d "," -f4`

echo -e '<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">'>>$report
echo -e "<td align="center" width="100">CNOUT_APP</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_2</td>">>$report
echo -e "</tr>">>$report

ofx01_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006547| cut -d "," -f4`
ofx01_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006548| cut -d "," -f4`
ofx02_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006549| cut -d "," -f4`
ofx02_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006550| cut -d "," -f4`
ofx03_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006551| cut -d "," -f4`
ofx03_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006552| cut -d "," -f4`

echo -e '<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">'>>$report
echo -e "<td align="center" width="100">ESP_APP</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_2</td>">>$report
echo -e "</tr>">>$report


ofx01_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006563| cut -d "," -f4`
ofx01_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws01.csv | grep 400006564| cut -d "," -f4`
ofx02_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006565| cut -d "," -f4`
ofx02_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws02.csv | grep 400006566| cut -d "," -f4`
ofx03_1=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006567| cut -d "," -f4`
ofx03_2=`cat /fras/cebscr/checkup/opsmon/bdc1rdftofxws03.csv | grep 400006568| cut -d "," -f4`


echo -e '<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">'>>$report
echo -e "<td align="center" width="100">SVLT_APP</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx01_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx02_2</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_1</td>">>$report
echo -e "<td align="center" width="100" bgcolor=green>$ofx03_2</td>">>$report
echo -e "</tr>">>$report
echo -e "</table>">>$report
